export interface Account{
    accountId:number;
    branch:String;
    accountType:String;
    amount:number;
}
